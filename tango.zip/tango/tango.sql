-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le : Ven 06 Janvier 2012 à 13:23
-- Version du serveur: 5.5.16
-- Version de PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `tango`
--

-- --------------------------------------------------------

--
-- Structure de la table `abonnes`
--

CREATE TABLE IF NOT EXISTS `abonnes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_abo` int(11) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Contenu de la table `abonnes`
--

INSERT INTO `abonnes` (`id`, `id_abo`, `id_user`) VALUES
(1, 2, 1),
(2, 1, 3),
(3, 2, 3),
(4, 3, 1),
(5, 1, 2),
(6, 1, 4),
(7, 2, 4);

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id_admin` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `tel` varchar(20) NOT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `auteur`
--

CREATE TABLE IF NOT EXISTS `auteur` (
  `id_auteur` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` int(11) DEFAULT NULL,
  `id_message` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_auteur`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=116 ;

--
-- Contenu de la table `auteur`
--

INSERT INTO `auteur` (`id_auteur`, `id_user`, `id_message`) VALUES
(1, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(6, 1, 6),
(7, 1, 7),
(8, 1, 8),
(9, 1, 9),
(10, 1, 10),
(11, 1, 11),
(12, 2, 12),
(13, 2, 13),
(14, 2, 14),
(15, 2, 15),
(16, 2, 16),
(17, 2, 17),
(18, 2, 18),
(19, 2, 19),
(20, 1, 20),
(21, 2, 21),
(22, 2, 22),
(23, 2, 1),
(24, 2, 2),
(25, 2, 3),
(26, 2, 4),
(27, 2, 5),
(28, 2, 6),
(29, 2, 7),
(30, 3, 8),
(31, 3, 9),
(32, 3, 10),
(33, 3, 11),
(34, 3, 12),
(35, 3, 13),
(36, 3, 14),
(37, 3, 15),
(38, 1, 16),
(39, 1, 17),
(40, 1, 18),
(41, 1, 19),
(42, 1, 20),
(43, 1, 21),
(44, 1, 22),
(45, 1, 23),
(46, 1, 24),
(47, 1, 25),
(48, 1, 26),
(49, 1, 27),
(50, 1, 28),
(51, 1, 29),
(52, 1, 30),
(53, 1, 31),
(54, 1, 32),
(55, 1, 33),
(56, 1, 34),
(57, 1, 35),
(58, 1, 36),
(59, 1, 37),
(60, 1, 38),
(61, 1, 39),
(62, 1, 40),
(63, 1, 41),
(64, 1, 42),
(65, 1, 43),
(66, 1, 44),
(67, 1, 45),
(68, 1, 46),
(69, 1, 47),
(70, 1, 48),
(71, 1, 49),
(72, 1, 50),
(73, 1, 51),
(74, 1, 52),
(75, 1, 53),
(76, 1, 54),
(77, 2, 55),
(78, 2, 56),
(79, 2, 57),
(80, 2, 58),
(81, 2, 59),
(82, 2, 60),
(83, 2, 61),
(84, 2, 62),
(85, 2, 63),
(86, 2, 64),
(87, 3, 65),
(90, 3, 68),
(91, 3, 69),
(92, 3, 70),
(93, 3, 71),
(94, 3, 72),
(95, 3, 73),
(96, 1, 74),
(97, 1, 75),
(98, 1, 76),
(99, 1, 77),
(100, 1, 78),
(101, 1, 0),
(102, 1, 0),
(103, 1, 0),
(104, 1, 0),
(105, 1, 0),
(106, 1, 0),
(107, 1, 0),
(108, 1, 0),
(109, 1, 0),
(110, 1, 0),
(111, 1, 0),
(112, 1, 98),
(113, 1, 99),
(114, 1, 100),
(115, 4, 101);

-- --------------------------------------------------------

--
-- Structure de la table `concept`
--

CREATE TABLE IF NOT EXISTS `concept` (
  `id_concept` int(11) NOT NULL AUTO_INCREMENT,
  `concept` varchar(30) NOT NULL,
  PRIMARY KEY (`id_concept`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `contenu`
--

CREATE TABLE IF NOT EXISTS `contenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_message` int(11) DEFAULT NULL,
  `id_concept` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `id_message` int(11) NOT NULL AUTO_INCREMENT,
  `message` varchar(160) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id_message`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=102 ;

--
-- Contenu de la table `message`
--

INSERT INTO `message` (`id_message`, `message`, `date`) VALUES
(1, '  bonjour', '0000-00-00 00:00:00'),
(2, '  bonjour', '0000-00-00 00:00:00'),
(3, '  bonjour', '0000-00-00 00:00:00'),
(4, '  bonsoir', '0000-00-00 00:00:00'),
(5, '  bonsoir', '0000-00-00 00:00:00'),
(6, '  bonsoir', '0000-00-00 00:00:00'),
(7, '  salut', '2011-12-29 01:40:12'),
(8, '   ', '2012-01-02 12:26:00'),
(9, '   ', '2012-01-02 12:26:54'),
(10, '   ', '2012-01-02 12:35:52'),
(11, ' ', '2012-01-02 12:37:01'),
(12, ' ', '2012-01-02 12:37:08'),
(13, '   ', '2012-01-02 12:38:58'),
(14, '   ', '2012-01-02 12:39:08'),
(15, ' ', '2012-01-02 12:39:25'),
(16, ' ', '2012-01-02 12:40:02'),
(17, '   ', '2012-01-02 12:41:53'),
(18, 'bonjour la terre', '2012-01-02 12:45:23'),
(19, ' ', '2012-01-02 12:46:19'),
(20, ' ', '2012-01-02 12:46:52'),
(21, ' ', '2012-01-02 12:47:25'),
(22, '   ', '2012-01-02 12:51:19'),
(23, '   ', '2012-01-02 12:51:46'),
(24, '   ', '2012-01-02 12:52:35'),
(25, '  salut les louzs', '2012-01-02 12:52:44'),
(26, '  salut les louzs', '2012-01-02 12:53:01'),
(27, '  salut les louzs', '2012-01-02 12:54:42'),
(28, '  salut les gars', '2012-01-02 12:54:49'),
(29, '  salut les gars', '2012-01-02 12:54:54'),
(30, '  salut les gars', '2012-01-02 12:55:27'),
(31, '  boooo', '2012-01-02 12:55:40'),
(32, '  boooo', '2012-01-02 12:55:44'),
(33, '  boooo', '2012-01-02 12:56:29'),
(34, '  sssss', '2012-01-02 12:56:36'),
(35, '  sssss', '2012-01-02 12:56:40'),
(36, '  sssss', '2012-01-02 12:56:57'),
(37, '  llllll', '2012-01-02 12:57:02'),
(38, '  llllll', '2012-01-02 12:57:05'),
(39, '  llllll', '2012-01-02 12:57:51'),
(40, '  ggggg', '2012-01-02 12:57:55'),
(41, '  ggggg', '2012-01-02 12:58:03'),
(42, '  ggggg', '2012-01-02 13:07:02'),
(43, '  ggggg', '2012-01-02 13:09:33'),
(44, '  ggggg', '2012-01-02 13:10:02'),
(45, '  ggggg', '2012-01-02 13:11:18'),
(46, '  ggggg', '2012-01-02 13:11:54'),
(47, '  ggggg', '2012-01-02 13:12:31'),
(48, '  ggggg', '2012-01-02 13:13:19'),
(49, '  ggggg', '2012-01-02 13:13:58'),
(50, '  ggggg', '2012-01-02 13:14:11'),
(51, '  ggggg', '2012-01-02 13:17:11'),
(52, '  ggggg', '2012-01-02 13:18:05'),
(53, '  ggggg', '2012-01-02 13:20:02'),
(54, '  ggggg', '2012-01-02 13:20:25'),
(55, '  ggggg', '2012-01-02 13:22:14'),
(56, '  ggggg', '2012-01-02 13:22:22'),
(57, '  ggggg', '2012-01-02 13:23:43'),
(58, '  ggggg', '2012-01-02 13:28:19'),
(59, '  ggggg', '2012-01-02 13:28:28'),
(60, '  ggggg', '2012-01-02 13:28:53'),
(61, '  ggggg', '2012-01-02 13:30:06'),
(62, '  ggggg', '2012-01-02 13:30:47'),
(63, '  ggggg', '2012-01-02 13:31:04'),
(64, '  ggggg', '2012-01-02 13:31:29'),
(65, '  stp regarde ce site <a href=http://www.bonjour.com target=_blank>bonjour.com</a>', '2012-01-02 14:38:36'),
(73, '  bonjour <a id=''lien'' href=blog.php?iduser=1 target=_blank>@Assiga</a>', '2012-01-02 15:36:02'),
(74, '  joseph', '2012-01-02 15:37:26'),
(75, '  bnjr', '2012-01-02 15:38:03'),
(76, '  bnjr', '2012-01-02 15:41:32'),
(77, '  bnjr', '2012-01-02 15:41:59'),
(78, '  bnjr', '2012-01-02 16:01:07'),
(79, '', '2012-01-02 16:01:39'),
(80, '', '2012-01-02 16:01:58'),
(81, '', '2012-01-02 16:03:13'),
(82, '  ggggg', '2012-01-02 16:04:25'),
(83, '  ggggg', '2012-01-02 16:04:52'),
(84, '', '2012-01-02 16:05:56'),
(85, '  ggggg', '2012-01-02 16:07:47'),
(86, '  ggggg', '2012-01-02 16:08:03'),
(87, '  ggggg', '2012-01-02 16:10:28'),
(88, '  ggggg', '2012-01-02 16:10:32'),
(89, '  ggggg', '2012-01-02 16:10:38'),
(90, '  ggggg', '2012-01-02 16:10:45'),
(91, '  ggggg', '2012-01-02 16:11:07'),
(92, '  ggggg', '2012-01-02 16:13:36'),
(93, '  ggggg', '2012-01-02 16:13:42'),
(94, '  ggggg', '2012-01-02 16:13:47'),
(95, '  ggggg', '2012-01-02 16:15:46'),
(96, '  ggggg', '2012-01-02 16:15:50'),
(97, '  ggggg', '2012-01-02 16:19:18'),
(98, '  ggggg', '2012-01-02 16:20:23'),
(99, '  ggggg', '2012-01-02 16:20:34'),
(100, '  <a href=http://www.google.fr target=_blank>google.fr</a>', '2012-01-05 19:42:28'),
(101, '  bonjour', '2012-01-05 19:44:01');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE IF NOT EXISTS `utilisateur` (
  `id_user` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(20) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `email` varchar(30) NOT NULL,
  `siteweb` varchar(30) NOT NULL,
  `biographie` varchar(160) NOT NULL,
  `avatar` text NOT NULL,
  `motpasse` varchar(10) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id_user`, `nom`, `prenom`, `email`, `siteweb`, `biographie`, `avatar`, `motpasse`) VALUES
(1, 'Assiga', 'joseph', 'joseph.assiga@gmail.com', 'josephAssiga.fr', 'Je suis avec vous la famille', 'Birthday Cake.bmp', 'Reussir7'),
(2, 'Hazem', 'ayari', 'ayari@gmail.com', '', '', '', 'Reussir6'),
(3, 'Deruy', '', 'damien@gmail.com', '', '', '', 'Reussir8'),
(4, 'Cauet', 'thomas', 'caeut@gmail.com', '', '', '', 'Reussir8'),
(5, 'Dubois', 'Alexis', 'alex@gmail.com', '', '', '', 'Reueeee8');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
