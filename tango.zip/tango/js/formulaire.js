/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

function surligne(champ, erreur)
{
   if(erreur)
      champ.style.backgroundColor = "#fba";
   else
      champ.style.backgroundColor = "";
}

function verifNom(champ)
{
   if(champ.value.length < 2 || champ.value.length > 25)
   {
      surligne(champ, true);
      return true;
   }
   else
   {
      surligne(champ, false);
      return false;
   }
}

function verifPrenom(champ)
{
   if(champ.value.length < 2 || champ.value.length > 25)
   {
      surligne(champ, true);
      return true;
   }
   else
   {
      surligne(champ, false);
      return false;
   }
}

function verifMail(champ)
{
   var regex = /^[a-zA-Z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$/;
   if(regex.test(champ.value))
   {
      surligne(champ, true);
      return true;
   }
   else
   {
      surligne(champ, false);
      return false;
   }
}

function verifForm(f)
{
   var nom = verifNom(f.pseudo);
   var prenom = verifPrenom(f.email);
   var mail = verifMail(f.age);
   
   if(nom && prenom && mail)
      return true;
   else
   {
      return false;
   }
}
function Verif_TextArea(f)
{
     $message = f.message.value;
     if( $message.length <= 160 && $message !="" )
      {
           
           f.submit();
           f.message.value = " ";
           return true;
                   
      }
      else
      {
          f.message.style.backgroundColor = "#fba";
          return false;
                   
      }  
            
 }
 
 function OuvriDial(f)
 {
     $( "#dialog-form" ).dialog( "open" );
 }