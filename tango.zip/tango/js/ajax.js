/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

             var inputs = document.getElementsByTagName('input');
            for(var i = 0,c = inputs.length ; i<c ;i++){
                alert('Element n° ' + (i + 1) + ' : ' + inputs[i]);
            }
  
