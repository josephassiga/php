<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
 <?php
 session_start();
 include_once 'connection.php';
   // Vérification des entrées:
     
  if(isset ($_POST['nom']) && isset ($_POST['email']) && isset ($_POST['password']))// -2-
  {
       $nom    = $_POST['nom'];
       $mail   = $_POST['email'];
       $mp     = $_POST['password'];
  }
  else if(isset ($_POST['nom']) && $_POST['prenom'] && $_POST['mail'] && $_POST['mot_de_passe'] )// -1-
  {
       $nom    = $_POST['nom'];
       $prenom = $_POST['prenom'];
       $mail   = $_POST['mail'];
       $mp     = $_POST['mot_de_passe'];
      
  }
  else if(isset ($_POST['nom']) && isset ($_POST['mot_de_passe']))// -3-
  {
           $nom    = $_POST['nom'];
           $mp    =  $_POST['mot_de_passe'];
  }
  
  if( isset($nom) && isset($prenom) && Verifmail($mail) && VerifMot_de_Passe($mp)) //-1-
   {
        //je fais une requêtte pour avoir tous les utilisateurs de la base
         $monId = FindUser($nom, $prenom);
         if($monId != 0)// si l'utilisateur esiste dans la base je recupère son id
         {
             $_SESSION['userId'] = $monId;
             
         }
         else // si l'utilisateur n'existe pas, alors je mets ces données dans la base.
         {
                 // On insère dans la table

           $con = connection();
           $rst = $con->prepare("insert into utilisateur(nom,prenom,email,motpasse) values(:nom,:prenom,:email,:motpasse)");
           $rst->execute(array(
               'nom'=>$nom,
               'prenom'=>$prenom,
               'email'=>$mail,
               'motpasse'=>$mp           
           ));
         
          $_SESSION['userId'] = $con->lastInsertId();
            
         }
         
        
         header("Location: ../php/blog.php");
   }
 
 else  if(isset($nom) && Verifmail($mail) && VerifMot_de_Passe($mp))// -2-
   {
       
       //je fais une requêtte pour avoir tous les utilisateurs de la base
         $monId =  FindUserId($nom);
         if($monId != -1)// si l'utilisateur esiste dans la base je recupère son id
         {
             $_SESSION['userId'] = $monId;
             
         }
         else // si l'utilisateur n'existe pas, alors je mets ces données dans la base.
         {
                 // On insère dans la table

           $con = connection();
           $rst = $con->prepare("insert into utilisateur(nom,email,motpasse) values(:nom,:email,:motpasse)");
           $rst->execute(array(
               'nom'=>$nom,
               'email'=>$mail,
               'motpasse'=>$mp           
           ));
         
          $_SESSION['userId'] = $con->lastInsertId();
            
         }
         header("Location: ../php/blog.php");
       
   }
   else if(isset($nom) && VerifMot_de_Passe($mp)) //-3-         
   {
           //je fais une requêtte pour avoir tous les utilisateurs de la base
             $monId = FindUserId($nom);
             if($monId != 0)// si l'utilisateur esiste dans la base je recupère son id
             {
                 $_SESSION['userId'] = $monId;

             }
             else // si l'utilisateur n'existe pas, alors je mets ces données dans la base.
             {
                     // On insère dans la table

               $con = connection();
               $rst = $con->prepare("insert into utilisateur(nom,motpasse) values(:nom,:motpasse)");
               $rst->execute(array(
                   'nom'=>$nom,
                   'motpasse'=>$mp           
               ));

              $_SESSION['userId'] = $con->lastInsertId();

             }
             header("Location: ../php/blog.php");
   }
   
   
 else
 {    
     
 ?>

	 <!-- Sinon, on affiche un message d'erreur-->

		 
       <!DOCTYPE html>
       <html>
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
            <link rel="stylesheet" href="../css/style2.css"/>
            <link href="/phoenix/boy_2.ico" rel="shortcut icon" type="image/x-icon"></link>
            <script src="../js/ajax.js" type="text/javascript"></script>
            <title>Verification inscription</title>
        </head>
        <body>
		 
	<div id="header" class="header">
            
            
        </div>
        
        
        <div id="corps_du_texte">
             
            <div id="verification">
                <form id="form_verification"  action="inscription.php" method="POST"  >
                    <input type="text" class="nom" id="nom" name="nom" value="<?php echo $nom; ?>" maxlength="126" required/><span></span>
                    <input type="text" class="prenom" id="prenom" name="prenom" value="<?php echo $prenom; ?>" maxlength="126" required /><span></span>
                    <input type="password" class="pass" id="pass" name="mot_de_passe" value=<?php echo $mp ?> maxlength="126" required /><span></span>
                    <input type="text"  class="mail" id="mail" name="mail" value=<?php echo $mail ?> required /><br/><span></span>
                    <input type="submit" value="s'inscrire" id="button" class="button"/>
                 </form>  
            </div>
            
         </div>
         
         <h1 style="color:red;text-align: center"> Connection echou&edot;e</h1>
         
    <?php    
    
    }
    
    ?>
       
    </body>
</html>
