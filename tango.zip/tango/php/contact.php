<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>MegaCorporate | Contact</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="../css/style_1.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../js/cufon-yui.js"></script>
<script type="text/javascript" src="../js/arial.js"></script>
<script type="text/javascript" src="../js/cuf_run.js"></script>
</head>
<body>
<div class="main">
  <?php include_once 'header2.php';?>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2><span>Contactez nous</span> ici</h2>
          <div class="clr"></div>
          <form action="contact.php" method="POST" id="sendemail">
            <ol>
              <li>
                <label for="name">Nom</label>
                <input id="name" name="name" class="text" />
              </li>
              <li>
                <label for="email">Adresse Email</label>
                <input id="email" name="email" class="text" />
              </li>
              <li>
                  <label for="website">Site Web</label>
                <input id="website" name="website" class="text" />
              </li>
              <li>
                <label for="message">Votre Message</label>
                <textarea id="message" name="message" rows="8" cols="50"></textarea>
              </li>
              <li>
                <input type="submit" name="imageField" id="imageField" class="send" />
                <div class="clr"></div>
              </li>
            </ol>
          </form>
        </div>
      </div>
        <?php
       /* if(isset ($_POST['name']) && isset ($_POST['email']) && isset ($_POST['website']) && isset ($_POST['message']))
        {
            $nom     = $_POST['name'];
            $email   = $_POST['email'];
            $site    = $_POST['website'];
            $message = $_POST['message'];
            
            
            
        
        
        
        $mail = 'joseph.assiga@gmail.fr'; // Déclaration de l'adresse de destination.
        if (!preg_match("#^[a-z0-9._-]+@(hotmail|live|msn|gmail).[a-z]{2,4}$#", $mail)) // On filtre les serveurs qui rencontrent des bogues.
        {
                $passage_ligne = "\r\n";
        }
        else
        {
                $passage_ligne = "\n";
        }
        //=====Déclaration des messages au format texte et au format HTML.
        //$message_txt = "Salut à tous, voici un e-mail envoyé par un script PHP.";
        $message_html = "<html><head></head><body><b>Salut à tous</b>,  
                         <h3>Mon Nom :</h3> $nom </br>
                         <h3>Mon Email :</h3> $email </br>
                         <h3>Message :</h3> $message </br>
                         </body></html>";
        //==========

        //=====Création de la boundary
        $boundary = "-----=".md5(rand());
        //==========

        //=====Définition du sujet.
        $sujet = "Sugestions !";
        //=========

        //=====Création du header de l'e-mail.
        $header = "From: \"WeaponsB\"<$mail>".$passage_ligne;
        $header.= "Reply-to: \"WeaponsB\" <joseph.assiga@gmail.fr>".$passage_ligne;
        $header.= "MIME-Version: 1.0".$passage_ligne;
        $header.= "Content-Type: multipart/alternative;".$passage_ligne." boundary=\"$boundary\"".$passage_ligne;
       
        //=====Ajout du message au format HTML
        $message.= "Content-Type: text/html; charset=\"ISO-8859-1\"".$passage_ligne;
        $message.= "Content-Transfer-Encoding: 8bit".$passage_ligne;
        $message.= $passage_ligne.$message_html.$passage_ligne;
        //==========
        $message.= $passage_ligne."--".$boundary."--".$passage_ligne;
        $message.= $passage_ligne."--".$boundary."--".$passage_ligne;
        //==========

        //=====Envoi de l'e-mail.
        mail($mail,$sujet,$message,$header);
        //==========
        }*/
        
        ?>
      
      <div class="clr"></div>
    </div>
  </div>
 <?php include_once 'footer.php'; ?> 
</div>
</body>
</html>
