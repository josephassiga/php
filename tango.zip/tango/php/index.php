<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->

<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" href="../css/style.css"/>
        <link href="../photo/boy_2.ico" rel="shortcut icon" type="image/x-icon"></link>
        <script type="text/javascript" src="../js/formulaire.js"></script>
        <title>tango</title>
    </head>
    <body>
        
        <div id="header">
            
            <form action="inscription.php" id="form_connection" class="form_connection" method="POST">
                <input type="text" name="nom" placeholder="Nom" required  /><span></span>
                <input type="password" name="mot_de_passe"  placeholder="mot de passe" required /><span></span>
                <input type="submit" value="se connecter" id="connection" class="connection"/>
            </form>
            
        </div>
         
        <div id="corps_du_texte">
        
            <div id="formulaire">
                <form name="form_inscription"  action="inscription.php" method="POST" onsubmit="return verifForm(form_inscription);"  >
                    <label for="nom">Nom:</label> <input type="text" class="nom" id="nom" name="nom" placeholder="votre nom" maxlength="126" required onblur="verifNom(this)" />
                    <label for="prenom">Prenom:</label> <input type="text" class="prenom" id="prenom" name="prenom" placeholder="votre prenom" maxlength="126" required onblur="verifPrenom(this)"/>
                    <label for="mp">Mot de Passe:</label> <input type="password" class="pass" id="pass" name="mot_de_passe" placeholder="mot de passe" maxlength="126" required  />
                    <label for="mail">Mail:</label> <input type="text"  class="mail" id="mail" name="mail" placeholder="example@me.com" required onblur="verifMail(this)"/><br/>
                    <input type="submit" value="s'inscrire" id="button" class="button"/>
                </form>  
            </div>
            
      </div>
        
    </body>
</html>
