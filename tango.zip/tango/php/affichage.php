<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<?php
// On démarre la session AVANT d'écrire du code HTML
session_start();
 
// On s'amuse à créer quelques variables de session dans $_SESSION
include_once 'connection.php';
$id=$_SESSION['userId'];

 $con = connection();
  try
{ 
$reponse= $con->query("SELECT nom, email FROM utilisateur where id_user = $id");
// On affiche chaque entrée une à une
    if ($donnees = $reponse->fetch())
    {
        $nom2=$donnees['nom'];
        $email=$donnees['email'];
    }else die( 'no result');
 $reponse->closeCursor();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link href="/phoenix/boy_2.ico" rel="shortcut icon" type="image/x-icon"></link>
         <link rel="stylesheet" href="../css/style3.css"/>
        <title>bonjour <?php $nom2; ?></title>
    </head>
    <body>
        <div id="header" class="header"></div>
        
        
        <div id="corps_du_texte">
            <h1> Bonjour <?php echo $nom2; ?></h1>
            <h2> votre adresse mail est : <?php echo $email; ?></h2>
        </div>
        
        <div id="foot"></div>
    </body>
</html>

<?php
}catch(Exception $e)
{
    // En cas d'erreur précédemment, on affiche un message et on arrête tout
    die('Erreur : '.$e->getMessage());
}
 
?>