<?php

function  connection()
{
    $dsn='localhost';
    $login='root';
    $password='';
    $bd='tango';
   try
   {
	$pdo_options[PDO::ATTR_ERRMODE] = PDO::ERRMODE_EXCEPTION;
        return new PDO('mysql:host='.$dsn.';dbname='.$bd, ''.$login.'', ''.$password.'', $pdo_options);
      
   }
    catch (Exception $e)
   {
            die('Erreur : ' . $e->getMessage());
   }

}

function VerifMot_de_Passe($mot_de_passe)
{
    if(isset ($mot_de_passe))
    {
        //je vérifie la taille : taille = 8 : commence par une lettre majuscule, suivi de 6 lettre minuscule
        //et se termine par un chiffre.
         if(strlen($mot_de_passe) == 8)
         {
             if(preg_match("#^[A-Z][a-z]{6}[0-9]$#", $mot_de_passe))
             {
                     return true; 
             }
         }
   
    }
    return false;      
        
 }
    
    
function Verifmail($mail)
{
    
     if (isset($mail))
     {

        if (preg_match("#^[a-z0-9._-]+@[a-z0-9._-]{2,}\.[a-z]{2,4}$#", $mail))
        {
            return true; 
        }
        else
        {
            return false;
        }
    }
}

function FindUser($user_nom,$user_prenom)
{
  try
  {
     $con     = connection();
     $sql     = "SELECT id_user FROM utilisateur WHERE nom=:nom AND prenom=:prenom";
     $reponse = $con->prepare($sql);
     $reponse->execute(array(
          'nom'=>$user_nom,
          'prenom'=>$user_prenom
     ));
     $rep = $reponse->fetch();
     if(!empty ($rep))
     {
         return $rep['id_user'];
     }
     else
     {
        return 0;
        
     }
      
  }
   catch (Exception $e)
   {
            die('Erreur : ' . $e->getMessage());
   }
   
   
}

function FindUserId($user_nom)
{
      try
      {
         $con     = connection();
         $sql     = "SELECT id_user FROM utilisateur WHERE nom=:nom";
         $reponse = $con->prepare($sql);
         $reponse->execute(array('nom'=>$user_nom));
         $rep = $reponse->fetch();
         if(!empty ($rep))
         {
             return $rep['id_user'];
         }
         else
         {
            return -1;

         }

      }
       catch (Exception $e)
       {
                die('Erreur : ' . $e->getMessage());
       }
   
   }
   
   function FindId($id_abonne,$id_user)
{
      try
      {
         $con     = connection();
         $sql     = "SELECT id_abo FROM abonnes WHERE id_abo=:id AND id_user=:id2";
         $reponse = $con->prepare($sql);
         $reponse->execute(array('id'=>$id_abonne, 'id2'=>$id_user));
         $rep = $reponse->fetch();
         if(!empty ($rep['id_abo']))
         {
             return 1;
         }
         else
         {
            return -1;

         }

      }
      catch (Exception $e)
       {
                die('Erreur : ' . $e->getMessage());
       }
   
   }
      
      function SupprimerMess($id_mess)
      {
      try
      {
         $con     = connection();
         $sql     = "DELETE FROM message WHERE message.id_message=:id_mess";
         $reponse = $con->prepare($sql);
         $reponse->execute(array('id_mess'=>$id_mess));
         
         if(!empty ($rep))
         {
             return true;
         }
         else
         {
            return false;

         }

      }
       
       catch (Exception $e)
       {
                die('Erreur : ' . $e->getMessage());
       }
   
   }
   
      function SupprimerAut($id_mess)
      {
      try
      {
         $con     = connection();
         $sql     = "DELETE FROM auteur WHERE auteur.id_message=:id_mess";
         $reponse = $con->prepare($sql);
         $reponse->execute(array('id_mess'=>$id_mess));
         
         if(!empty ($rep))
         {
             return true;
         }
         else
         {
            return false;

         }

      }
       
       catch (Exception $e)
       {
                die('Erreur : ' . $e->getMessage());
       }
   
   }
   
    function  Retwit($id_mess, $id_user)
      {
      try
      {
         $con     = connection();
         $sql     = "INSERT INTO auteur (id_user,id_message) VALUES(:id_user,:id_message)";
         $reponse = $con->prepare($sql);
         $reponse->execute(array(
             'id_user'=>$id_user,
             'id_message' =>$id_mess    
             ));
         if(!empty ($rep))
         {
             return true;
         }
         else
         {
            return false;

         }

      }
       
       catch (Exception $e)
       {
                die('Erreur : ' . $e->getMessage());
       }
   
   }
   
   function  RetwitMess($id_mess)
      {
      try
      {
         $con     = connection();
         $sql     = "SELECT message.message FROM message WHERE message.id_message=:id_mess";
         $reponse = $con->prepare($sql);
         $reponse->execute(array('id_mess'=>$id_mess));
         $rep = $reponse->fetch();
         if(!empty ($rep))
         {
             return $rep['message'];
         }
         else
         {
            return false;

         }

      }
       
       catch (Exception $e)
       {
                die('Erreur : ' . $e->getMessage());
       }
   
   }

   
   function  RetwitMess2($mess,$date)
      {
      try
      {
          $tmp=$date;
         $con     = connection();
         $sql     = "INSERT INTO message(message,date) VALUES(:message,:date)";
         $reponse = $con->prepare($sql);
         $reponse->execute(array(
             'message'=>$mess,
             'date' =>$date
             ));
         
          $sql     = "SELECT message.id_message FROM message WHERE date=:date";
         $reponse = $con->prepare($sql);
         $reponse->execute(array(
             'date' =>$tmp
             ));
         $rep = $reponse->fetch();
         if(!empty ($rep))
         {
             return $rep['id_message'];
         }
         else
         {
            return false;

         }

      }
       
       catch (Exception $e)
       {
                die('Erreur : ' . $e->getMessage());
       }
   
   }
?>
