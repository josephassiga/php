<?php
// Définit le fuseau horaire par défaut à utiliser. Disponible depuis PHP 5.1
date_default_timezone_set('UTC');
 setlocale (LC_TIME, 'fr-FR'); 
 session_start();
 include_once 'connection.php';
 $con   = connection();
 

// $id    = $_SESSION['userId'];
 $_SESSION['userId'] = isset ($_GET['iduser'])? (int)$_GET['iduser'] : $_SESSION['userId'];
 
 $id    = $_SESSION['userId'];
// Connexion à la base de données
try
{
   
   if(isset($_POST['message'])&& $_POST['message'] != " ")
   {
       

       $message  = $_POST['message'];
       $date     = date("Y-m-d H:i:s");
       $pmessage = explode(" ", $message);
       $message2 = " ";
       foreach($pmessage as $val)
       {
               if(preg_match("#^www#i", $val))
               {

                  $val2 =substr($val, 4);
                  $val2="<a href=http://$val target=_blank>$val2</a>";
                  $message2 .=" ".$val2;

               }
               else if(preg_match("#^@#", $val))
               {
                   //je recupère son id dans la base;
                    $login=substr($val, 1);// je recupère son nom
                    $iduser= FindUserId($login);
                    if(isset($iduser ) && !empty ($iduser))
                    {
                       $val2="<a id='lien' href=blog.php?iduser=$iduser target=_blank>$val</a>";
                       $message2 .=" ".$val2; 
                       
                    }
               } 
               else if(preg_match("#^http://www#", $val))
                {
                               
                        $val2=substr($val, 7);
                        $val2="<a id='lien' href=http://$val2>$val</a>";
                        $message2 .=" ".$val2;
                }
               else 
               {

                  $message2 .=" ". $val; 
                 
               }
                          
      }

       
       // Insertion du message à l'aide d'une requête préparée
        $sql="INSERT INTO message(message,date) VALUES(:message,:date)";
        $req = $con->prepare($sql);
        $req->execute(array(
        'message'=>  html_entity_decode($message2), 
        'date'=>     $date
        ));
            $id_message = $con->lastInsertId();
        
        $sql= "INSERT INTO auteur(id_user,id_message) VALUES(:id_us,:id_mes)";
        $req = $con->prepare($sql);
        $req->execute(array(
        'id_us'=> mysql_real_escape_string($id), 
        'id_mes'=>mysql_real_escape_string( $id_message)
        ));
   }
    
    
   
   
    
}
catch(Exception $e)
{
    die('Erreur : '.$e->getMessage());
}

 

    $reponse= $con->query("SELECT nom FROM utilisateur where id_user = $id");
    if($donnees = $reponse->fetch())
    {
        $nom = $donnees['nom'];
        
    }
    else
    {
         die( 'no result');
    }
    $reponse->closeCursor();




?>
    
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
    <html xmlns="http://www.w3.org/1999/xhtml">
    <head>
    <title>tango | Blog</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="../css/style_1.css" rel="stylesheet" type="text/css" />
    <link type="text/css" href="../css/start/jquery-ui-1.8.16.custom.css" rel="Stylesheet" />
    <script type="text/javascript" src="../js/jquery.js"></script>
    <script type="text/javascript" src="../js/menu.js"></script>
    <script type="text/javascript" src="../js/jquery-1.6.2.min.js"></script>
    <script type="text/javascript" src="../js/jquery-ui-1.8.16.custom.min.js"></script>
    <script type="text/javascript" src="../js/formulaire.js"></script>
    
    <style>
#lien		 
a:link { text-decoration: none; color:#3366FF; }
a:visited { text-decoration: none; color:#3366FF; }
a:hover { text-decoration: none; color:#999999; }

		
		input.text { margin-bottom:12px; width:95%; padding: .4em; }
		fieldset { padding:0; border:0; margin-top:25px; }
		h1 { font-size: 1.2em; margin: .6em 0; }
		.ui-dialog .ui-state-error { padding: .3em; }
		.validateTips { border: 1px solid transparent; padding: 0.3em; }
    </style>
    
    <script type="text/javascript" >
        
	$(function() {
		$( "#tabs" ).tabs().scrollabletab(); 
                            
	});
        
        
	</script>
    </head>
    <body>
   <div class="main">
       
       
<?php include_once 'header.php';?>
  </div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
               
         <div class="demo">

            <div id="dialog-form" title="Connection">
                    <p class="validateTips">Toutes les valeurs sont nécessaires.</p>

                    <form id="connection" action="inscription.php" method="POST">
                    <fieldset>
                            <label for="name">Name</label>
                            <input type="text" name="nom" id="name" class="text ui-widget-content ui-corner-all" />
                            <label for="email">Email</label>
                            <input type="text" name="email" id="email" value="" class="text ui-widget-content ui-corner-all" />
                            <label for="password">Password</label>
                            <input type="password" name="password" id="password" value="" class="text ui-widget-content ui-corner-all" />
                            
                    </fieldset>
                    </form>
            </div>
        </div>
        
               
               
    <div id="tabs" class="container">
	<ul>
		<li><a href="#tabs-1">Fil</a></li>
                <li><a href="#tabs-2">Abonn&eacute;s</a></li>
		<li><a href="#tabs-3">Activit&eacute;s</a></li>
                <li><a href="#tabs-4">Recherches</a></li>
                <li><a href="#tabs-5">Listes</a></li>
                <li><a href="#tabs-6">Membres</a></li>
                <li><a href="#tabs-7">Compte</a></li>
	</ul>
        <div id="tabs-1" class="panel" >
                <div class="article">
                   <form action="blog.php" method="POST" id="leaverepl" name="form_mess">
                    <ol>
                      <li>
                        <label for="message">Votre Message</label>
                        <textarea id="message" name="message" rows="8" cols="60"></textarea>
                      </li>
                      <li>
                        <input type="button" name="imageField" id="imageField" class="send" value="Envoyer" onclick="Verif_TextArea(form_mess)" />
                      </li>
                    </ol>
                  </form>
                </div>
            
            
            <?php
            // --- Fil de message -----
                // Connexion à la base de données
                try
                {     //je recupère le message
                     
              
                            
                      if(isset ($_GET['id_mess']) && !empty ($_GET['id_mess']) )
                       {
                                    $id1 = $_GET['id_mess'];
                                    $id2 = SupprimerMess($id1);
                                    $id2 = SupprimerAut($id1);
                       }
                      if(isset ($_GET['id_twit']) && !empty ($_GET['id_twit']) )
                       {
                                    $id1 = $_GET['id_twit'];
                                    
                                    $id3 = RetwitMess($id1);
                                    $date     = date("Y-m-d H:i:s");
                                    $id4 = RetwitMess2($id3,$date);
                                    $id2 = Retwit($id4,$id);
                                   
                       }
                      if(isset ($_GET['iduser']))
                      {
                           $id2 =  $_GET['iduser'];
                           $sql = "SELECT  message, date FROM message join auteur 
                                   ON auteur.id_message=message.id_message WHERE auteur.id_user=$id2
                                   ORDER BY message.id_message DESC LIMIT 0, 10";
                      
                      
                      }else
                      {
                           $sql="SELECT  message.id_message,message, date FROM message join auteur 
                             ON auteur.id_message=message.id_message WHERE auteur.id_user=$id
                             ORDER BY message.id_message DESC LIMIT 0, 10";
                      
                          
                      }
                      // Récupération des 10 derniers messages
                      
                         $reponse = $con->query($sql);
                     // Affichage de chaque message (toutes les données sont protégées par htmlspecialchars)
                        while ($donnees = $reponse->fetch())
                        {
                ?>  
            
            

                    <div class="article">
                          <div class="comment"> <a href="#"><img src="../photo/userpic.gif" width="40" height="40" alt="" class="userpic" /></a>
                          <p> <?php echo  htmlspecialchars($nom); ?> : <p> <?php echo htmlspecialchars($donnees['date']);?></p><br /></p>
                          <p> <?php echo  html_entity_decode($donnees['message']);?></p>
                          <p><a href="blog.php?id_mess=<?php echo $donnees['id_message'];?>" style="color: red">Supprimer</a></p>
                      </div>
                     </div>
                 
         
            
               <?php
                       }

                       $reponse->closeCursor();
                    
                    //}
                }
                catch(Exception $e)
                {
                    die('Erreur : '.$e->getMessage());
                }

                ?>  
            
	</div>
	<div id="tabs-2" class="panel" >
		 <?php // --- Abonnés -----
                // Connexion à la base de données

                        try
                        {
                            
                            if(isset ($_GET['id']) && !empty ($_GET['id']) && ($id != $_GET['id']))
                            {
                                    $id1 = $_GET['id'];
                                    $id2 = FindId($id1,$id);// Si je regarde si cet abonné est déjà dans la base.

                                if($id2 < 0)
                                {

                                    // Récupération des 10 derniers messages

                                    $sql="INSERT INTO abonnes(id_abo,id_user) VALUES(:idabo,:iduser)";
                                    $req = $con->prepare($sql);
                                           $req->execute(array(
                                           'idabo'=>     mysql_real_escape_string($id1), 
                                           'iduser'=>    mysql_real_escape_string($id)
                                        ));
                                }
                            }
                               $sql="SELECT  nom, prenom FROM utilisateur
                                     WHERE id_user IN 
                                     (SELECT id_abo FROM abonnes
                                     WHERE abonnes.id_user=$id) ORDER BY nom";
                                    

                                //$reponse = $con->query("SELECT message, date FROM message  ORDER BY id_message DESC LIMIT 0, 10");
                               $reponse = $con->query($sql);

                                // Affichage de chaque message (toutes les données sont protégées par htmlspecialchars)
                                while ($donnees = $reponse->fetch())
                                {
                      ?>  

                         

                              <div class="comment"> <a href="#"><img src="../photo/userpic.gif" width="40" height="40" alt="" class="userpic" /></a>
                              <p><a href="#"><?php echo  htmlspecialchars($donnees['nom'])." ". htmlspecialchars($donnees['prenom']);?></a></p>

                              </div>
                       <?php
                               }

                               $reponse->closeCursor();


                        }
                        catch(Exception $e)
                        {
                            die('Erreur : '.$e->getMessage());
                        }
                   
                ?>  
	</div>
	<div id="tabs-3"  class="panel" >
            
		 <?php
                 // --- Activité des Utilisateurs chez qui je suis abonnés. -----         
                 // Connexion à la base de données

                        try
                        {
                         
                            if(isset ($_GET['iduser']) && !empty($_GET['iduser']))$id=(int)$_GET['iduser'];
                            
                              $sql="SELECT utilisateur.nom,utilisateur.id_user,message.message, message.date,message.id_message FROM
                                     utilisateur, message, abonnes, auteur  WHERE
                                     abonnes.id_user=$id AND auteur.id_user=abonnes.id_abo AND utilisateur.id_user=abonnes.id_abo AND message.id_message=auteur.id_message
                                     ORDER BY message.id_message DESC LIMIT 0, 10";
                                    

                                //$reponse = $con->query("SELECT message, date FROM message  ORDER BY id_message DESC LIMIT 0, 10");
                               $reponse = $con->query($sql);

                                // Affichage de chaque message (toutes les données sont protégées par htmlspecialchars)
                                while ($donnees = $reponse->fetch())
                                {
                                    
                      ?>  

                         

                              <div class="comment"> <a href="#"><img src="../photo/userpic.gif" width="40" height="40" alt="" class="userpic" /></a>
                              <p><a href="blog.php?iduser=<?php echo $donnees['id_user'];?>"  target="_blank"><?php echo  htmlspecialchars($donnees['nom'])?></a>  <?php echo htmlspecialchars($donnees['date']);?></p>
                              <p><?php echo htmlspecialchars($donnees['message']);?></p>
                              <p><a href="blog.php?id_twit=<?php echo $donnees['id_message'];?>" style="color: blue">Retwitter</a></p>
                              </div>
                       <?php
                               }

                               $reponse->closeCursor();


                        }
                        catch(Exception $e)
                        {
                            die('Erreur : '.$e->getMessage());
                        }
                   
                ?>  
		
	</div>
        
        <div id="tabs-4"  class="panel" >
		
		
	</div>
        <div id="tabs-5"  class="panel" >
                
		
	</div>
        
        <div id="tabs-6"  class="panel" >
                
             <?php
                // Connexion à la base de données
                try
                {
                    
                        // Récupération des 10 derniers messages
                       $sql="SELECT  nom, prenom,id_user FROM utilisateur";
                             
                        //$reponse = $con->query("SELECT message, date FROM message  ORDER BY id_message DESC LIMIT 0, 10");
                       $reponse = $con->query($sql);

                        // Affichage de chaque message (toutes les données sont protégées par htmlspecialchars)
                        while ($donnees = $reponse->fetch() )
                        {
                            if($donnees['id_user'] != $id)
                           {
                    ?>

                      <div class="comment"> <a href="#"><img src="../photo/userpic.gif" width="40" height="40" alt="" class="userpic" /></a>
                      <p><a href="#"><?php echo  htmlspecialchars($donnees['nom'])." ". htmlspecialchars($donnees['prenom']);?></a> <a href="blog.php?id=<?php echo $donnees['id_user'];?>" style="color: red">Suivre</a></p>
                           
                      </div>
               <?php
               
                             }
                       }

                       $reponse->closeCursor();
                    
                    
                }
                catch(Exception $e)
                {
                    die('Erreur : '.$e->getMessage());
                }

                ?>  
		
	</div>
        
        <div id="tabs-7"  class="panel">
            <?php 
            // --- Modifications des enregistrements du user. -----
              $sql ="SELECT * FROM utilisateur WHERE id_user = $id";
               //$reponse = $con->query("SELECT message, date FROM message  ORDER BY id_message DESC LIMIT 0, 10");
              $reponse = $con->query($sql);
               ?>
             <h2>Modifiez les Informations de votre profil :</h2>
             <div id="formulaire">
             <?php
                        // Affichage de chaque message (toutes les données sont protégées par htmlspecialchars)
               while ($donnees = $reponse->fetch() )
                        {
                            
                       
              ?>
            
           
                    <form name="form_inscription"  action="blog.php" method="POST" onsubmit="return verifForm(form_inscription);" enctype="multipart/form-data" >
                    <label for="nom">Nom:</label> <input type="text" class="nom" size="25" id="nom" name="nom" placeholder="votre nom" maxlength="126" required onblur="verifNom(this)" value="<?php echo $donnees['nom'];?>"/>
                    <label for="prenom">Prenom:</label> <input type="text" class="prenom" size="25" id="prenom" name="prenom" placeholder="votre prenom" maxlength="126" required onblur="verifPrenom(this)" value="<?php echo $donnees['prenom'];?>"/>
                    <label for="mp">Mot de Passe:</label> <input type="text" class="pass" size="25" id="pass" name="mot_de_passe" placeholder="mot de passe" maxlength="126" required  value="<?php echo $donnees['motpasse'];?>"/>
                     <label for="mp">Site Web:</label> <input type="text" class="pass" size="25" id="pass" name="site" placeholder="Site web" maxlength="126" required  value="<?php echo $donnees['siteweb'];?>"/>
                     <label for="mail">Mail:</label> <input type="text"  class="mail" size="25" id="mail" name="mail" placeholder="example@me.com" required onblur="verifMail(this)" value="<?php echo $donnees['email'];?>"/>
                     <label for="mail">Biographie:</label>  <textarea rows="8" cols="60" name="biographie"> <?php echo $donnees['biographie']; ?></textarea>
                     <input type="hidden" name="MAX_FILE_SIZE" value="12345" />
                     <label for="prenom">Avatar:</label> <input type="file" class="prenom" id="prenom" name="avatar" placeholder="télécharger votre photo" maxlength="126" required/><br></br>
                     <input type="submit" value="Enregistrer" id="button" class="button" name="upload"/>
                </form>  
                </div>
            <?php 
          }
              
            
        
            if( isset ($_POST['nom']) && isset ($_POST['prenom'])&& isset($_POST['mot_de_passe'])&& isset($_POST['mail'])
                && $_POST['biographie'] && isset($_FILES['avatar']) && isset($_POST['upload']) && isset($_POST['site']) ){            
            
               //Penser à faire la vérification la taille du champ biographie
              $nom1         = $_POST['nom'];
              $prenom       = $_POST['prenom'];
              $passw        = $_POST['mot_de_passe'];
              $mail1        = $_POST['mail'];
              $bio          = $_POST['biographie'];
              $content_dir  = '../avatar'; // dossier où sera déplacé le fichier
              $avatar_user  = $_FILES['avatar']['name'];
              $site         = $_POST['site'];
             // echo " nom avatar ". $avatar_user;
                $tmp_file = $_FILES['avatar']['tmp_name'];
               // echo "test ".$tmp_file;

              /*  if( !is_uploaded_file($tmp_file) )
                {   echo "1";
                    //exit(-1);
                    
                }

                // on vérifie maintenant l'extension
                $type_file = $_FILES['avatar']['type'];

                if( !strstr($type_file, 'jpg') && !strstr($type_file, 'jpeg') && !strstr($type_file, 'bmp') && !strstr($type_file, 'gif') )
                {
                     //exit(-1);
                     echo "2";
                }*/

                // on copie le fichier dans le dossier de destination
                $name_file = $_FILES['avatar']['name'];

                if( !move_uploaded_file($tmp_file, "$content_dir/$name_file") )
                {
                   
                    exit(-1);
                }

                $sql="UPDATE utilisateur SET nom=:nom,prenom=:prenom,email=:email,siteweb=:siteweb,biographie=:biographie,avatar=:avatar,motpasse=:motpasse WHERE utilisateur.id_user = $id";
                $req = $con->prepare($sql);
                $req->execute(array(
                   'nom'        =>        mysql_real_escape_string($nom1),
                   'prenom'     =>        mysql_real_escape_string($prenom),
                   'email'      =>        mysql_real_escape_string($mail1),
                   'siteweb'    =>        mysql_real_escape_string($site),
                   'biographie' =>        mysql_real_escape_string($bio),
                   'avatar'     =>        mysql_real_escape_string($avatar_user),
                   'motpasse'   =>        mysql_real_escape_string($passw)
                   
                   
                          ));
   
            }
            
            ?>
		
	</div>
        
    </div>
      
      </div>
      <div class="clr"></div>
    </div>
  </div>
  
  
    <?php include_once 'footer.php'; ?>
  
</body>
</html>     

