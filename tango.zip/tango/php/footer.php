 <div class="fbg">
    <div class="fbg_resize">
      
      
    </div>
    <div class="footer">
      <p class="lf"><a href="#">Assiga Joseph </a></p>
      <p style="margin-left: 35em"><a href="#">Projet PHP - Licence Informatique </a></p>
      <p style="margin-top: -15px" class="rf"><a href="#">Damien Deruy</a></p>
      
      <div class="clr"></div>
    </div>
  </div>
