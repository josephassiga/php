<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>tango | A propos</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="../css/style_1.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="../js/cufon-yui.js"></script>
<script type="text/javascript" src="../js/arial.js"></script>
<script type="text/javascript" src="../js/cuf_run.js"></script>
</head>
<body>
<div class="main">
  <?php include_once 'header2.php';?>
</div>
  <div class="content">
    <div class="content_resize">
      <div class="mainbar">
        <div class="article">
          <h2><span>Principe</span> Général</h2>
          <div class="clr"></div>
          L'objectif est de construire un site de micro-bloging, dans le style <strong>Twiter</strong>. Le principe est de permettre aux utilisateurs du site  d'envoyer 
          de brefs messages et d'être mis au courant des messages envoyés par certains des autres utilisateurs.
          <ul>
              <li><h3>Notion de message:</h3></li> Un message est un texte (au moins 160 caractères - caractères et non crochets) contenant des métats
                                         informations , renvoyant à d'autres pages.
               <li><h3>Notion dd'utilisateur :</h3></li> Un utilisateur est identifié par un système de login et de mot de passe. il dispose d'un rpofil contenant
                                               éventuelement un avatar, son réel nom, une courte biogra^hie(160 caractère maximum) et un site web. Ces
                                               informations peuvent être modifiées à tout moment et sont accessible en lecture aux autres utilisateurs.
                                               
               <li><h3>Notion de Renvoi :</h3></li> Il est possible d'envoyer à nouveau (retweet dans la terminologie de Twiiter) le message d'un autre utilisateur d'un 
                                           simple click. Dans ce cas, le message est ajouté  à la liste de messages envoyés par l'utilisateur, avec la mention <strong>retransmis de</strong> suivi du login
                                           de l'auteur original.
              
              
          </ul>
          
        </div>
      </div>
      <div class="clr"></div>
    </div>
  </div>
  <?php include_once 'footer.php'; ?>
</body>
</html>
