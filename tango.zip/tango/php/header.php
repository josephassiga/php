<div class="header">
    <div class="header_resize">
      <div class="logo">
          <h1><a href="index.php" style="font-size:36px">tan<span>go</span></a></h1>
      </div>
      <div class="menu_nav">
        <ul>
          <li class="active"><a href="index.php"><span>Home</span></a></li>
          <li><a href="apropos.php"><span>A propos</span></a></li>
          <li><a href="contact.php"><span>Contact</span></a></li>
          <li><a href="#" class="cancel"><span>Se connecter</span></a></li>
           <!--<button id="create-user"><span>Se connecter</span></button>-->
        </ul>
      </div>
      <div class="clr"></div>
      <div class="header_img"><img src="../photo/main_img.png" alt="" width="271" height="234" />
        <h2>Projet PHP - Licence Informatique</h2>
        <p><strong>Suivez Vos Passions</strong><br />
         Recevez des nouvelles instantanées de vos amis, d'experts, de vos starts préférées, et de ce qui se passe partout dans le monde.
         Parlez, exprimez vos idées et faites changer le monde.
        </p>
        <div class="clr"></div>
      </div>
    </div>
  </div>

