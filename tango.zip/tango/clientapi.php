<!--
To change this template, choose Tools | Templates
and open the template in the editor.
-->
<!DOCTYPE html>
<?php
 include './xmlrpc/xmlrpc.inc';

?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link href="../css/style.css" rel="stylesheet" type="text/css" />
         <script type="text/javascript" src="../js/formulaire.js"></script>
        <title>Projet PHP | API PHP </title>
    </head>
    <body>
        <h1 style="text-align: center"> API pour le Projet PHP</h1>
        
       
            
            
              <div class="article" style="padding-left: 35%">
                  <form action=clientapi.php" method="POST" id="leaverepl" name="form_mess">
                   
                     
                       <label for="message">Votre Message</label><br/>
                        <textarea id="message" name="message" rows="8" cols="60"></textarea><br/>
                        <input type="submit" name="imageField" id="imageField" class="send" value="Envoyer" onclick="this.value=''"/>
                    
                  </form>
                </div>
        
        
        
         <?php
        // Play nice to PHP 5 installations with REGISTER_LONG_ARRAYS off
	if(!isset($HTTP_POST_VARS) && isset($_POST))
	{
		$HTTP_POST_VARS = $_POST;
	}

	if(isset($HTTP_POST_VARS["message"]) && $HTTP_POST_VARS["message"]!="")
	{
		$message=(integer)$HTTP_POST_VARS["message"];
		$f=new xmlrpcmsg('examples.getStateName',
			array(php_xmlrpc_encode($message))
		);
		//print "<pre>Sending the following request:\n\n" . htmlentities($f->serialize()) . "\n\nDebug info of server data follows...\n\n";
		$c=new xmlrpc_client("./serverapi.php", "localhost", 80);
		$c->setDebug(1);
		$r=&$c->send($f);
		if(!$r->faultCode())
		{
			$v=$r->value();
			print "</pre><br/>State number " . $message. " is "
				. htmlspecialchars($v->scalarval()) . "<br/>";
			
		}
		else
		{
			print "An error occurred: ";
			print "Code: " . htmlspecialchars($r->faultCode())
				. " Reason: '" . htmlspecialchars($r->faultString()) . "'</pre><br/>";
		}
	}
	else
	{
		$message = "";
	}
        ?>
    </body>
</html>
