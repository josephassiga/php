<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Verification inscription</title>
        <style type="text/css">
a:link { text-decoration: none; color:#400080; }
a:visited { text-decoration: none; color:#400080; }
a:hover { text-decoration: none; color:#FF0080; }
</style>
        
    </head>
    <body>
       
	<?php 
         /* include_once './php/connection.php';
          // $message = $_POST['message'];
                   $message = "Bonjour je suis assiga, coucou http://www.lefigaro.fr/flash-eco/2011/12/19/97002-20111219FILWWW00391-du-mieux-pour-l-immobilier-aux-usa.php contacter moi ici www.bonjour.fr";
                      $pmessage = explode(" ", $message);
                       $message2 =" ";
                      foreach($pmessage as $val)
                      {
                          echo $val."</br>";
                          //<a href="http://www.allhtml.com">Découvrez ALL HTML</a>
                            if(preg_match("#^www#i", $val))
                            {
                                 $val2=substr($val, 1);
                                 echo"val1 ". $val2."</br>";
                                 $val2="<a href=http://$val>$val</a>";
                                 //echo " ".$val2;
                                 $message2 .=" ".$val2;
                                
                            }
                            else if(preg_match("#^http://www#", $val))
                            {
                               
                                 $val2=substr($val, 7);
                                 echo"val2 ". $val2."</br>";
                                 $val2="<a href=http://$val2>$val</a>";
                                 $message2 .=" ".$val2;
                            }
                            else
                            {
                                  $message2 .=" ". $val; 
                            }
                          
                           
                      }
                      
                      echo $message2;
     /*     $user_id = 1;
         // $id = FindId($user_id);
          $date     = date("d-m-Y H:i:s");
          echo "valeur de id = ".$date;
          ?>
        <form method="POST" action="test.php" enctype="multipart/form-data">    
          <input type="hidden" name="MAX_FILE_SIZE" value="12345">    
          <input type="file" name="fichier">   
          <input type="submit" name="upload" value="Envoyer">   
        </form>
        <?php  
      
            if( isset($_POST['upload']) ) // si formulaire soumis
            {
                $content_dir = './avatar'; // dossier où sera déplacé le fichier

                $tmp_file = $_FILES['fichier']['tmp_name'];

                if( !is_uploaded_file($tmp_file) )
                {
                    exit("Le fichier est introuvable");
                }

                // on vérifie maintenant l'extension
                $type_file = $_FILES['fichier']['type'];

                if( !strstr($type_file, 'jpg') && !strstr($type_file, 'jpeg') && !strstr($type_file, 'bmp') && !strstr($type_file, 'gif') )
                {
                    exit("Le fichier n'est pas une image");
                }

                // on copie le fichier dans le dossier de destination
                $name_file = $_FILES['fichier']['name'];

                if( !move_uploaded_file($tmp_file, "$content_dir/$name_file") )
                {
                    exit("Impossible de copier le fichier dans $content_dir");
                }

                echo "Le fichier a bien été uploadé";
            }*/

?>
	 </body>
</html>